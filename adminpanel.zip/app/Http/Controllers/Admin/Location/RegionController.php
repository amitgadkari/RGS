<?php

namespace App\Http\Controllers\Admin\Location;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\State;

use App\Region;

use Validator;

class RegionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

/*
*Desc : main page
*
* @params:
*
* @returns : 
*/

    public function index()
    {
        $states=State::distinct()->pluck('name','id');
        // dd($states);

        $regions=Region::latest()->get();
        
        return view('adminpanel.location.region.index',compact('regions'))->with('states',$states);  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $states=State::distinct()->pluck('name','id');
        //dd('hello1');
        return view('adminpanel.location.region.micros.create_regions',compact('states'))->render();
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd('sad');

        $this->validate($request, [
        'regionname' => 'required|max:100',
        'States'=> 'exists:states,id'

        ]);

        if($request){

            $region=new Region;
            $region->name=$request->regionname;
            $region->state_id=$request->States;
            $region->employee_id='0';
            $region->save();    

         }

        
        
        
   
        //dd('hello2');
        
        //return view('adminpanel.index');    }
    }
    function show_view()
    {
        $regions=Region::latest()->get();
            return view('adminpanel.location.region.micros.show_regions',compact('regions'))->render();
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        dd('hello3');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        dd('hello4');    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    /*
    *Desc :To create new subregion
    *
    * @params:
    *
    * @returns : 
    */
    public function createsub()
    {
        dd('hello5');
    }


    /*
    *Desc :To store the subregion
    *
    * @params:
    *
    * @returns : 
    */
    public function storesub()
    {
        dd('hello6');
    }


    /*
    *Desc : to edit the subregion
    *
    * @params:
    *
    * @returns : 
    */


    public function editsub($id)
    {
        dd('hello7');
    }


    /*
    *Desc : to update the subregion
    *
    * @params:
    *
    * @returns : 
    */

    public function updatesub(Request $request, $id)
    {
        dd('hello8');
    }



    /*
    *Desc : to search the region 
    *
    * @params:
    *
    * @returns : 
    */

    public function search()
    {

    }
}
